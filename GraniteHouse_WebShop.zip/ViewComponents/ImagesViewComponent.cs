﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GraniteHouse_WebShop.Models;
using GraniteHouse_WebShop.Data;
using System;
namespace GraniteHouse_WebShop.ViewComponents
{
    public class ImagesViewComponent : ViewComponent
    {
        private readonly ApplicationDbContext _db;

        public ImagesViewComponent(ApplicationDbContext db)
        {
            _db = db;
        }
        public async Task<IViewComponentResult> InvokeAsync(string Seller)
        {
            var items = await GetItemsAsync(Seller);
            return View(items);
        }
        private Task<List<Images>> GetItemsAsync(string Seller)
        {
            return _db.Images.Where(s =>s.Seller == Seller).ToListAsync();
        }
    }
}