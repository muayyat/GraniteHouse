using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using GraniteHouse_WebShop.Data;
using GraniteHouse_WebShop.Models;
using GraniteHouse_WebShop.Models.ViewModel;
using GraniteHouse_WebShop.Utility;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
namespace GraniteHouse_WebShop.Areas.Admin.Controllers
{
    [Authorize]
    public class BookingsController : Controller
    {
        //database object gets by dependency injection
        private readonly ApplicationDbContext _db;
        private readonly HostingEnvironment _hostingEnvironment;
        
        [BindProperty]
        public BookingsVM BookingsVM { get; set; }
        public BookingsController(ApplicationDbContext db, HostingEnvironment hostingEnvironment)
        {
            _db = db;
            _hostingEnvironment = hostingEnvironment;

            BookingsVM = new BookingsVM()
            {
                Bookings = new Models.Bookings()
            };
        }
        [Route("Bookings")]
        public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            ViewData["CurrentSort"] = sortOrder;
            ViewData["BookingIDSortParm"] = String.IsNullOrEmpty(sortOrder) ? "bookingID_desc" : "";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewData["CurrentFilter"] = searchString;
            var sellery = HttpContext.User.Identity.Name;
            var bookings = from s in _db.Bookings.Where(s =>s.Seller == sellery)
                           select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                bookings = bookings.Where(s => s.BookingId.Contains(searchString) 
                || s.Approval.Contains(searchString));
            }
            switch (sortOrder)
            {
                case "bookingID_desc": bookings = bookings.OrderByDescending(s => s.BookingId);
                    break;
                case "Date": bookings = bookings.OrderBy(s => s.BDate);
                    break;
                case "date_desc": bookings = bookings.OrderByDescending(s => s.BDate);
                    break;
                default: bookings = bookings.OrderBy(s => s.Id);
                    break;
            }
            int pageSize = 3;
            return View(await PaginatedList<Bookings>.CreateAsync(bookings.AsNoTracking(), page ?? 1, pageSize));
        }

        // GET Edit Action Method
        public async Task<IActionResult> Booking(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var booking = await _db.Bookings.FindAsync(id);
            if (booking == null)
            {
                return NotFound();
            }
            var sellery = HttpContext.User.Identity.Name;

            if (booking.Seller != sellery)
            {
                return NotFound();
            }
            var stg = _db.Products.FirstOrDefaultAsync(s => s.ServiceId == booking.Service);
            // ViewBag.Servname = stg.Name;
            // ViewBag.Servmage = stg.Logo;
           
            return View(booking);
        }

        // Post Edit action method
       [HttpPost]
       [ValidateAntiForgeryToken]
        public async Task<IActionResult> Booking(int id, Bookings bookings)
        {
#pragma warning disable CS0472 // The result of the expression is always the same since a value of this type is never equal to 'null'
            if (id == null)
#pragma warning restore CS0472 // The result of the expression is always the same since a value of this type is never equal to 'null'
            {
                return NotFound();
            }
            var sellery = HttpContext.User.Identity.Name;
            var studentToUpdate = await _db.Bookings.SingleOrDefaultAsync(s => s.Id == id);
            if (studentToUpdate.Seller == sellery)
            {
                if (await TryUpdateModelAsync<Bookings>(
                studentToUpdate,
                "",
                s => s.Approval, s => s.ADate, s => s.ANote))
                {
                    try
                    {
                        await _db.SaveChangesAsync();
                        return RedirectToAction(nameof(Index));
                    }
                    catch (DbUpdateException /* ex */)
                    {            //Log the error (uncomment ex variable name and write a log.)           
                        ModelState.AddModelError("", "Unable to save changes. " +
                            "Try again, and if the problem persists, " +
                            "see your system administrator.");
                    }
                }
            }
            return View(bookings); }
        
        // GET Details Action Method
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var booking = await _db.Bookings.FindAsync(id);
            if (booking == null)
            {
                return NotFound();
            }
            var sellery = HttpContext.User.Identity.Name;

            if (booking.Seller != sellery)
            {
                return NotFound();
            }
            return View(booking);
        }

    }
}