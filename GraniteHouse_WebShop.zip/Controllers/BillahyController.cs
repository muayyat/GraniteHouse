﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GraniteHouse_WebShop.Data;
using GraniteHouse_WebShop.Models;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace GraniteHouse_WebShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BillahyController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public BillahyController(ApplicationDbContext context)
        {
            _context = context;
        }



        // GET: api/Billahy/5
        public async Task<IActionResult> GetToken()
        {
         
            using (var client = new HttpClient())
            {
                var payload = new { name = "cool", created = "0001-01-01T00:00:00", updated= "0001-01-01T00:00:00" };
                var url = new Uri($"https://localhost:44302/api/qonji");
                var response = await client.PostAsync(url, new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json"));

                string json;
                using (var content = response.Content)
                {
                    json = await content.ReadAsStringAsync();
                }

                return Ok(json);
            }
        }

        // PUT: api/Billahy/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBookings([FromRoute] int id, [FromBody] Bookings bookings)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != bookings.Id)
            {
                return BadRequest();
            }

            _context.Entry(bookings).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BookingsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Billahy
        [HttpPost]
        public async Task<IActionResult> PostBookings([FromForm] Bookings bookings)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.Bookings.Add(bookings);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBookings", new { id = bookings.Id }, bookings);
        }

        // DELETE: api/Billahy/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBookings([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var bookings = await _context.Bookings.FindAsync(id);
            if (bookings == null)
            {
                return NotFound();
            }

            _context.Bookings.Remove(bookings);
            await _context.SaveChangesAsync();

            return Ok(bookings);
        }

        private bool BookingsExists(int id)
        {
            return _context.Bookings.Any(e => e.Id == id);
        }
    }
}