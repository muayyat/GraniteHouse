using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using GraniteHouse_WebShop.Data;
using GraniteHouse_WebShop.Models;
using GraniteHouse_WebShop.Models.ViewModel;
using GraniteHouse_WebShop.Utility;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;

namespace GraniteHouse_WebShop.Controllers
{
    [Authorize]
    public class ImagesController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly HostingEnvironment _hostingEnvironment;

        [BindProperty]
        public ImagesVM ImagesVM { get; set; }
        public ImagesController(ApplicationDbContext db, HostingEnvironment hostingEnvironment)
        {
            _db = db;
            _hostingEnvironment = hostingEnvironment;

            ImagesVM = new ImagesVM()
            {
                Images = new Models.Images()
            };
        }
      




        // Post Delete action method
        // Post Delete action method
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var image = await _db.Images.FindAsync(id);
            var sellery = HttpContext.User.Identity.Name;
            if (image.Seller == sellery)
            {
                _db.Images.Remove(image);
                await _db.SaveChangesAsync();

                var dir = Path.Combine(_hostingEnvironment.WebRootPath, SD.ImageFolder);
                var imagePath = Path.Combine(dir, image.Link);

                if (System.IO.File.Exists(imagePath)) { 
                    System.IO.File.Delete(imagePath);
                }
                return RedirectToAction(nameof(Index));

            }
            else
            {
                return NotFound();
            }
        }


        // GET Edit Action Method
        public async Task<IActionResult> Item(int? id)
        {
            var sellery = HttpContext.User.Identity.Name;
            if (id == null)
            {
                return NotFound();
            }
            var image = await _db.Images.FindAsync(id);
            if (image == null)
            {
                return NotFound();
            }

            if (image.Seller != sellery)
            {
                return NotFound();
            }
            //if (Subs.Subscription.AddDays(30) < DateTime.Now)
            //{
            return View(image);

            //}
            //else {
            //   return View("~/Areas/Admin/Views/Subscriptions/Renewal.cshtml");
            // }

        }

        //GET Create Action Method
        public IActionResult Index()
        {
            var sellery = HttpContext.User.Identity.Name;
            return View();
          }
        
        //Post: Images Create Method
        // By using ActionName("Create") we can use whatever name of the create method
        [HttpPost,ActionName("Index")]
        public async Task<IActionResult> IndexPOST(ICollection<IFormFile> files)
        {
          
            // Image being saved
            string webRootPath = _hostingEnvironment.WebRootPath;

            // 
            if (files.Count > 0) {
            foreach (var file in files)
            {
              
              
                        // Image has been uploaded
                        var uploads = Path.Combine(webRootPath, SD.ImageFolder);
                var extension = Path.GetExtension(file.FileName);
                var filu = Path.GetFileNameWithoutExtension(file.FileName);
                var newfile = Path.Combine(filu + extension);
                var filexist = Path.Combine(uploads, filu + extension);
                using (var filestream = new FileStream((filexist), FileMode.Create))
                {
                    file.CopyTo(filestream);
                }
                
                var sellery = HttpContext.User.Identity.Name;
                var iLink = newfile ;
                await _db.Images.AddAsync(new Images { Seller = sellery, Link = iLink, Date = DateTime.Now });

            }
            await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }




      


    }
}