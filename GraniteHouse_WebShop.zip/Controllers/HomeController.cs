﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GraniteHouse_WebShop.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.EntityFrameworkCore;
using GraniteHouse_WebShop.Data;
using GraniteHouse_WebShop.Models.ViewModel;
using GraniteHouse_WebShop.Utility;
using Microsoft.AspNetCore.Hosting;
namespace GraniteHouse_WebShop.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly HostingEnvironment _hostingEnvironment;

        [BindProperty]
        public ProfilesVM ProfilesVM { get; set; }
        public ProfilesVM BookingsVM { get; set; }
        public ProfilesVM ProductsVM { get; set; }
        public HomeController(ApplicationDbContext db, HostingEnvironment hostingEnvironment)
        {
            _db = db;
            _hostingEnvironment = hostingEnvironment;

            ProfilesVM = new ProfilesVM()
            {
                Profiles = new Models.Profiles()
                
            };
            
        }
        [AllowAnonymous]
        public IActionResult Index()
        {
            var sellery = HttpContext.User.Identity.Name;
            var bookings = _db.Bookings.Where(s => s.Seller == sellery && string.IsNullOrWhiteSpace(s.Approval)).Count();
            ViewBag.Bookings = bookings;
            if (HttpContext.User.Identity.IsAuthenticated)
            {
                ViewBag.Link = "dashboard";
            }
            else
            {
                ViewBag.Link = "identity/account/register";
            }
            return View();
        }

        [AllowAnonymous]
        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        [Route("Privacy")]
        [AllowAnonymous]
        public IActionResult Privacy()
        {
            return View();
        }
        [Route("Dashboard")]
        public async Task<IActionResult> Dashboard()
        {
            var sellery = HttpContext.User.Identity.Name;
            var profilesu = await _db.Profiles.FirstOrDefaultAsync(s => s.Seller == sellery);
            if (profilesu == null)
            {
                await _db.Profiles.AddAsync(new Profiles { Seller = sellery, Category = "Services" });
            }
            await _db.SaveChangesAsync();

            var products = _db.Products.Where(s => s.Seller == sellery && s.Approval == "Approved").Count();
            var bookings = _db.Bookings.Where(s => s.Seller == sellery && string.IsNullOrWhiteSpace( s.Approval)).Count();
            var fulfilments =_db.Bookings.Where(s => s.Seller == sellery &&  s.Approval == "Approved" && string.IsNullOrWhiteSpace(s.Fulfilment)).Count();
            var payments =_db.Bookings.Where(s => s.Seller == sellery &&  s.Payment == "Paid").Count();
            ViewBag.Bookings = bookings;
            ViewBag.Products = products;
            ViewBag.Fulfilments = fulfilments;
            ViewBag.Payments = payments;

             if (string.IsNullOrWhiteSpace(profilesu.Address) || string.IsNullOrWhiteSpace(profilesu.BizName)
                || string.IsNullOrWhiteSpace(profilesu.BizCountry) || string.IsNullOrWhiteSpace(profilesu.Fullname))
            {
                ViewBag.Configure = "Finish your setup to start selling on Styrin. ";
            }
            else
            {
                ViewBag.Configure = "";
            }
            
            return View();
        }

        //Setup Configurations
        [Route("Account/Setup")]
        public  IActionResult SetupIndex()
        {
            var sellery = HttpContext.User.Identity.Name;
            //Check if user has settings already
            var profilesu = _db.Profiles.FirstOrDefault(s => s.Seller == sellery);
           if (profilesu == null)
            {
              _db.Profiles.Add(new Profiles { Seller = sellery});
            }
           _db.SaveChanges();
          
            return View(profilesu);
        }



        // GET Edit Action Method

        public async Task<IActionResult> EditSetup(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var profiles = await _db.Profiles.FindAsync(id);
            if (profiles == null)
            {
                return NotFound();
            }
            var sellery = HttpContext.User.Identity.Name;

            if (profiles.Seller != sellery)
            {
                return NotFound();
            }

            return View(profiles);
        }


        // Post Edit action method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditSetup(int id, Profiles profiles)
        {
#pragma warning disable CS0472 // The result of the expression is always the same since a value of this type is never equal to 'null'
            if (id == null)
#pragma warning restore CS0472 // The result of the expression is always the same since a value of this type is never equal to 'null'
            {
                return NotFound();
            }
            var sellery = HttpContext.User.Identity.Name;
                var setupToUpdate = await _db.Profiles.SingleOrDefaultAsync(s => s.Id == id && s.Seller == sellery);
                if (await TryUpdateModelAsync<Profiles>(
                    setupToUpdate,
                    "",
                    s => s.Fullname, s => s.Updated, s => s.BankActName, s => s.Address, s => s.Niche, s => s.Policy,
                    s => s.Bizmail, s => s.BizReg, s => s.Offers, s => s.Orders, s => s.Tips, s => s.Country, s => s.Method, s => s.BankName,
                    s => s.BankCountry, s => s.BankActNo, s => s.BankSwift, s => s.Paypal, s => s.BizName, s => s.BizCountry, s => s.BizAddress
                    ))
                {
                    try
                    {

                        await _db.SaveChangesAsync();
                        return RedirectToAction(nameof(SetupIndex));
                    }
                    catch (DbUpdateException /* ex */)
                    {            //Log the error (uncomment ex variable name and write a log.)           
                        ModelState.AddModelError("", "Unable to save changes. " +
                            "Try again, and if the problem persists, " +
                            "see your system administrator.");
                    }
                }
                return View(profiles);
            }
        


        //Get Create
        public IActionResult CreateSet()
        {
            return View(ProfilesVM);
        }

        //Post: Products Create Method
        // By using ActionName("Create") we can use whatever name of the create method
        [HttpPost, ActionName("CreateSet")]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> CreateSetupPOST()
        {
            if (!ModelState.IsValid)
            {
                return View(ProfilesVM);
            }
           
            _db.Profiles.Add(ProfilesVM.Profiles);
            await _db.SaveChangesAsync();
            var profilesFromDb = _db.Profiles.Find(ProfilesVM.Profiles.Id);

            var sellery = HttpContext.User.Identity.Name;
            profilesFromDb.Seller = sellery;
            await _db.SaveChangesAsync();

            return RedirectToAction(nameof(SetupIndex));
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
