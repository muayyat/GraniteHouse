﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GraniteHouse_WebShop.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.EntityFrameworkCore;
using GraniteHouse_WebShop.Data;
using GraniteHouse_WebShop.Models.ViewModel;
using GraniteHouse_WebShop.Utility;
using Microsoft.AspNetCore.Hosting;
namespace GraniteHouse_WebShop.Controllers
{
    [Authorize]
    public class SubscriptionsController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly HostingEnvironment _hostingEnvironment;

        [BindProperty]
        public SubscriptionsVM SubscriptionsVM { get; set; }
        public SubscriptionsVM BookingsVM { get; set; }
        public SubscriptionsVM ProductsVM { get; set; }
        public SubscriptionsController(ApplicationDbContext db, HostingEnvironment hostingEnvironment)
        {
            _db = db;
            _hostingEnvironment = hostingEnvironment;

            SubscriptionsVM = new SubscriptionsVM()
            {
                Subscriptions = new Models.Subscriptions()
            };
            
        }


        public async Task<IActionResult> Index()
        {
            var sellery = HttpContext.User.Identity.Name;
            //Check if user has settings already
            var subscriptionsy = _db.Subscriptions.Where(s => s.Seller == sellery);
            return View(await subscriptionsy.ToListAsync());
        }
        //GET Create Action Method

        public IActionResult Renewal()
        {
            return View(ProductsVM);
        }

        //Post: Products Create Method
        // By using ActionName("Create") we can use whatever name of the create method
        [HttpPost, ActionName("Renewal")]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> CreatePOST()
        {
            if (!ModelState.IsValid)
            {
                return View(SubscriptionsVM);
            }
            var sellery = HttpContext.User.Identity.Name;
           // _db.Profiles.Add(new Profiles { Seller = sellery, LastSubscribed = DateTime.Now });
          //  _db.Subscriptions.Add(new Subscriptions { Seller = sellery, Plan = "Standard", DatePayed = DateTime.Now, Ending = DateTime.Now});
            await _db.SaveChangesAsync();

            var subscriptionsFromDb = _db.Subscriptions.Find(SubscriptionsVM.Subscriptions.Id);
            subscriptionsFromDb.Seller = sellery;
            
            await _db.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }




        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
