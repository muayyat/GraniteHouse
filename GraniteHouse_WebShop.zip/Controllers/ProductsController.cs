using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using GraniteHouse_WebShop.Data;
using GraniteHouse_WebShop.Models;
using GraniteHouse_WebShop.Models.ViewModel;
using GraniteHouse_WebShop.Utility;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
namespace GraniteHouse_WebShop.Controllers
{
    [Authorize]
    public class ProductsController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly HostingEnvironment _hostingEnvironment;

        [BindProperty]
        public ProductsVM ProductsVM { get; set; }
        public ProductsController(ApplicationDbContext db, HostingEnvironment hostingEnvironment)
        {
            _db = db;
            _hostingEnvironment = hostingEnvironment;

            ProductsVM = new ProductsVM()
            {
                Products = new Models.Products()
            };
        }
        public async Task<IActionResult> Index()
        {
            var sellery = HttpContext.User.Identity.Name;
            var products = _db.Products.Where(s => s.Seller == sellery);
           // var productsy = await _db.Profiles.FirstAsync(s => s.Seller == sellery);
            return View(await products.ToListAsync());
            
        }



        // GET Edit Action Method
        public async Task<IActionResult> Item(string link)
        {
            var sellery = HttpContext.User.Identity.Name;
            if (link == null)
            {
                return NotFound();
            }
            var Subs =await _db.Profiles.SingleAsync(s => s.Seller == sellery) ;
            var products = await _db.Products.FirstOrDefaultAsync(s=>s.ViewLink==link);
            if (products == null)
            {
                return NotFound();
            }
           
            if (products.Seller != sellery)
            {
                return NotFound();
            }
            //if (Subs.Subscription.AddDays(30) < DateTime.Now)
            //{
                return View(products);

            //}
            //else {
             //   return View("~/Areas/Admin/Views/Subscriptions/Renewal.cshtml");
           // }

        }

        // Post Edit action method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Item(int id, Products products)
        {
#pragma warning disable CS0472 // The result of the expression is always the same since a value of this type is never equal to 'null'
            if (id == null)
#pragma warning restore CS0472 // The result of the expression is always the same since a value of this type is never equal to 'null'
            {
                return NotFound();
            }

            var sellery = HttpContext.User.Identity.Name;
            var studentToUpdate = await _db.Products.SingleOrDefaultAsync(s => s.Id == id);
            if (studentToUpdate.Seller == sellery) { 
            if (await TryUpdateModelAsync<Products>(
                studentToUpdate,
                "",
                s => s.Name, s => s.Updated, s => s.Description, s => s.Details, s => s.Active, s => s.Phone, s => s.Price,
                s => s.Locations, s => s.Email, s => s.Category, s => s.Address
                ))
            {
                try
                {
                   

                    await _db.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateException /* ex */)
                {            //Log the error (uncomment ex variable name and write a log.)           
                    ModelState.AddModelError("", "Unable to save changes. " +
                        "Try again, and if the problem persists, " +
                        "see your system administrator.");
                }
                }
                else
                {
                    return NotFound();
                }
            }
            return View(products);
        }


        

        // Post Delete action method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var products = await _db.Products.FindAsync(id);
            var sellery = HttpContext.User.Identity.Name;
            if (products.Seller == sellery) { 
            _db.Products.Remove(products);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
            }
            else
            {
                return NotFound();
            }
        }
        //GET Create Action Method
        public IActionResult Create()
        {
            var sellery = HttpContext.User.Identity.Name;
            var xty = _db.Products.Where(s => s.Seller == sellery).Count();
             if (xty == 0) { 
            return View(ProductsVM);
            }
            else
            {
                return RedirectToAction(nameof(Index));
            }
        }
        
        //Post: Products Create Method
        // By using ActionName("Create") we can use whatever name of the create method
        [HttpPost,ActionName("Create")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreatePOST()
        {
            if (!ModelState.IsValid)
            {
                return View(ProductsVM);
            }
           
            _db.Products.Add(ProductsVM.Products);
            var productsFromDb = _db.Products.Find(ProductsVM.Products.Id);
            productsFromDb.Seller = HttpContext.User.Identity.Name;

            await _db.SaveChangesAsync();

            return RedirectToAction("Item", new { link = ProductsVM.Products.ViewLink });
        }

    }
}