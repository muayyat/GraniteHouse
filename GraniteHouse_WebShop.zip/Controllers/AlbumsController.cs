using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using GraniteHouse_WebShop.Data;
using GraniteHouse_WebShop.Models;
using GraniteHouse_WebShop.Models.ViewModel;
using GraniteHouse_WebShop.Utility;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;

namespace GraniteHouse_WebShop.Controllers
{
    [Authorize]
    public class AlbumsController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly HostingEnvironment _hostingEnvironment;

        [BindProperty]
        public AlbumsVM AlbumsVM { get; set; }
        public AlbumsController(ApplicationDbContext db, HostingEnvironment hostingEnvironment)
        {
            _db = db;
            _hostingEnvironment = hostingEnvironment;

            AlbumsVM = new AlbumsVM()
            {
                Albums = new Models.Albums()
            };
        }
      




        // Post Delete action method
        // Post Delete action method
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var album = await _db.Albums.FindAsync(id);
            var sellery = HttpContext.User.Identity.Name;
            if (album.Seller == sellery)
            {
                _db.Albums.Remove(album);
                await _db.SaveChangesAsync();

                var dir = Path.Combine(_hostingEnvironment.WebRootPath, SD.AlbumsFolder);
                var albumPath = Path.Combine(dir, album.Link);

                if (System.IO.File.Exists(albumPath)) { 
                    System.IO.File.Delete(albumPath);
                }
                return RedirectToAction(nameof(Index));

            }
            else
            {
                return NotFound();
            }
        }


        // GET Edit Action Method
        public async Task<IActionResult> Item(int? id)
        {
            var sellery = HttpContext.User.Identity.Name;
            if (id == null)
            {
                return NotFound();
            }
            var album = await _db.Albums.FindAsync(id);
            if (album == null)
            {
                return NotFound();
            }

            if (album.Seller != sellery)
            {
                return NotFound();
            }
            //if (Subs.Subscription.AddDays(30) < DateTime.Now)
            //{
            return View(album);

            //}
            //else {
            //   return View("~/Areas/Admin/Views/Subscriptions/Renewal.cshtml");
            // }

        }

        //GET Create Action Method
        public IActionResult Index()
        {
            var sellery = HttpContext.User.Identity.Name;
            var albums = _db.Albums.Where(s => s.Seller == sellery);
            return View(albums.ToListAsync());
        }
        
        //Post: Images Create Method
        // By using ActionName("Create") we can use whatever name of the create method
        [HttpPost,ActionName("Index")]
        public async Task<IActionResult> IndexPOST()
        {
            if (!ModelState.IsValid)
            {
                return View(AlbumsVM);
            }

            _db.Albums.Add(AlbumsVM.Albums);
            var productsFromDb = _db.Albums.Find(AlbumsVM.Albums.Id);
            productsFromDb.Seller = HttpContext.User.Identity.Name;
            productsFromDb.Date = DateTime.Now;
            
            await _db.SaveChangesAsync();

            string webRootPath = _hostingEnvironment.WebRootPath;
            var album = productsFromDb.Link;
            string path = Path.Combine(webRootPath, SD.AlbumsFolder);
            Directory.CreateDirectory(album);
           
            
            return RedirectToAction(nameof(Index));
        }




      


    }
}