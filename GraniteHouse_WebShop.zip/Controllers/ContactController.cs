﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GraniteHouse_WebShop.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.EntityFrameworkCore;
using GraniteHouse_WebShop.Data;
using GraniteHouse_WebShop.Models.ViewModel;
using GraniteHouse_WebShop.Utility;
using Microsoft.AspNetCore.Hosting;
namespace GraniteHouse_WebShop.Controllers
{
    [Authorize]
    public class ContactController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly HostingEnvironment _hostingEnvironment;

        [BindProperty]
        public ContactVM ContactVM { get; set; }
        public ContactController(ApplicationDbContext db, HostingEnvironment hostingEnvironment)
        {
            _db = db;
            _hostingEnvironment = hostingEnvironment;
            ContactVM = new ContactVM()
            {
                Contact = new Models.Contact(),
           
            };
          
        }
        
        public async Task<IActionResult> Index()
        {
            var sellery = HttpContext.User.Identity.Name;
            var listy = _db.Contact.Where(s => s.Seller == sellery);
            return View(await listy.ToListAsync());
        }

      
        
        
      

        //Get Create
        public IActionResult Create()
        {
            return View(ContactVM);
        }

        //Post: Products Create Method
        // By using ActionName("Create") we can use whatever name of the create method
        [HttpPost, ActionName("Create")]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> CreatePOST()
        {
            if (!ModelState.IsValid)
            {
                return View(ContactVM);
            }
          
            _db.Contact.Add(ContactVM.Contact);
            await _db.SaveChangesAsync();

            var contactFromDb = _db.Contact.Find(ContactVM.Contact.Id);
            var sellery = HttpContext.User.Identity.Name;
            contactFromDb.Seller = sellery;
            contactFromDb.Date = DateTime.Now;
            
            await _db.SaveChangesAsync();
            ViewBag.Status = "We have received your message and will get back to you as soon as possible through your email.";

            return RedirectToAction(nameof(Index));
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
