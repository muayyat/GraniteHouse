﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GraniteHouse_WebShop.Utility
{
    public class SD
    {
        public const string DefaultProductImage = "default_image.png";
        public const string DefaultSetupImage = "default_image.png";
        public const string ImageFolder = @"images\Logo";
        public const string AlbumsFolder = @"images\Albums";
    }
}
