﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
namespace GraniteHouse_WebShop.Models
{
    public class Subscriptions
    {
        [Key]
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Display(Name = "Seller")]
        public string Seller { get; set; }
        
        
        [Display(Name = "Status")]
        public string Status { get; set; }

        [Display(Name = "Ending")]
        public string Ending { get; set; }

        [Display(Name = "Date Payed")]
        public string DatePayed { get; set; }

        [Display(Name = "Subscription Plan")]
        public string Plan { get; set; }


    }
}
