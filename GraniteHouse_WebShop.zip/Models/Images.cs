﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace GraniteHouse_WebShop.Models
{
    public class Images
    {
        public int Id { get; set; }
        public int ServiceId { get; set; }
        public string Link { get; set; }
        public string Seller { get; set; }
        public DateTime Date { get; set; }
        public int Album { get; set; }
     
    }
}
