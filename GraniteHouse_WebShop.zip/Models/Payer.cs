﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
namespace GraniteHouse_WebShop.Models
{
    public class Payer
    {
        public int Id { get; set; }
        public string PayToken { get; set; }
        public DateTime Initiated{ get; set; }
        public int Amount { get; set; }
        public string User { get; set; }
        public string Ref { get; set; }
        public string Status { get; set; }
        public string Purpose { get; set; }
        
    }
}
