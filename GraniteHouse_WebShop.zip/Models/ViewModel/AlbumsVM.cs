﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GraniteHouse_WebShop.Models.ViewModel
{
    public class AlbumsVM
    {
        public Albums Albums { get; set; }

    }
}
