﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GraniteHouse_WebShop.Models.ViewModel
{
    public class BookingsVM
    {
        public Bookings Bookings { get; set; }
       
    }
}
