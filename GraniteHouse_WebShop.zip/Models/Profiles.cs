﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
namespace GraniteHouse_WebShop.Models
{
    public class Profiles
    {
        [Key]
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Display(Name = "Seller")]
        public string Seller { get; set; }

        //Personal Info
        [Display(Name = "Fullname")]
        public string Fullname { get; set; }

        [Display(Name = "Country")]
        public string Country { get; set; }

        [Display(Name = "State")]
        public string State { get; set; }

        [Display(Name = "Address")]
        public string Address { get; set; }

        
        [Display(Name = "Last Subscription")]
        public DateTime Subscription { get; set; }


        //Payment info
        [Display(Name = "Method")]
        public string Method { get; set; }

        [Display(Name = "Bank")]
        public string BankName { get; set; }

        [Display(Name = "Bank Country")]
        public string BankCountry { get; set; }

        [Display(Name = "Bank Account No")]
        public string BankActNo { get; set; }

        [Display(Name = "Bank SWIFT")]
        public string BankSwift { get; set; }

        [Display(Name = "Bank Account Name")]
        public string BankActName { get; set; }

        [Display(Name = "Paypal Email")]
        public string Paypal { get; set; }


        //Business Info
        [Display (Name ="Category")]
        public string Category { get; set; }

        [Display(Name = "Niche")]
        public string Niche { get; set; }

        [Display(Name = "Business Email")]
        public string Bizmail { get; set; }

        [Display(Name = "Business Name")]
        public string BizName { get; set; }

        [Display(Name = "Country")]
        public string BizCountry { get; set; }

        [Display(Name = "Address")]
        public string BizAddress { get; set; }


        [Display(Name = "Registered")]
        public string BizReg { get; set; }

        [Display(Name = "Policy")]
        public string Policy { get; set; }

        // Notification Settings
        [Display(Name = "Tips")]
        public string Tips { get; set; }

        [Display(Name = "Order")]
        public string Orders { get; set; }


        [Display(Name = "Offers")]
        public string Offers { get; set; }


        [Display(Name = "Last Updated Date")]
        public DateTime Updated { get; set; }


    }
}
