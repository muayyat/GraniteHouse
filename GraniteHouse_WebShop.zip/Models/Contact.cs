﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
namespace GraniteHouse_WebShop.Models
{
    public class Contact
    {
        [Key]
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Display(Name = "Seller")]
        public string Seller { get; set; }

        [Display(Name = "Date")]
        public DateTime Date { get; set; }

        [Display(Name = "Source")]
        public string Source { get; set; }

        [Display(Name = "Details")]
        public string Details { get; set; }

        [Display(Name = "Status")]
        public string Status { get; set; }
        
        
    }
}
