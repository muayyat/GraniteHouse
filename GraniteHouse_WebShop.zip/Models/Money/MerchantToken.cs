﻿using System;
using System.Collections.Generic;

namespace GraniteHouse_WebShop.Models
{
    public class MerchantToken
    {
        public string Status { get; set; }
        public string Token { get; set; }
       }
}