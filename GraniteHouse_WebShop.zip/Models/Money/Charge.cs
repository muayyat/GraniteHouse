﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
namespace GraniteHouse_WebShop.Models
{
    public class Charge
    {
        //Personal info
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("firstname")]
        public string Firstname { get; set; }

        [JsonProperty("lastname")]
        public string Lastname { get; set; }

        [JsonProperty("phonenumber")]
        public string Phone { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("recepient")]
        public string Recepient { get; set; }

        [JsonProperty("amount")]
        public int Amount { get; set; }

        [JsonProperty("fee")]
        public int Fee { get; set; }

        [JsonProperty("redirecturl")]
        public string Rdr { get; set; }

        [JsonProperty("medium")]
        public string Medium { get; set; }

        [JsonProperty("chargeCurrency")]
        public string Chargecurrency { get; set; }

        [JsonProperty("disburseCurrency")]
        public string Disbursecurrency { get; set; }

        [JsonProperty("charge_with")]
        public string Chargewith { get; set; }

        [JsonProperty("transactionRef")]
        public string TransactionRef { get; set; }

        //Bank
        [JsonProperty("recepient")]
        public string RecepientActNumber { get; set; }

        [JsonProperty("recepient_bank")]
        public string RecepientBank { get; set; }

        [JsonProperty("authType")]
        public string AuthType { get; set; }

        [JsonProperty("authValue")]
        public string AuthValue { get; set; }

        [JsonProperty("sender_account_number")]
        public string SenderAct { get; set; }

        [JsonProperty("sender_bank")]
        public string SenderBank { get; set; }

        //Card
        [JsonProperty("card_no")]
        public string Cardno { get; set; }

        [JsonProperty("cvv")]
        public string Cvv { get; set; }

        [JsonProperty("expiry_year")]
        public string ExpiryYear { get; set; }

        [JsonProperty("expiry_month")]
        public string ExpiryMonth { get; set; }

        
        [JsonProperty("otp")]
        public string OTP { get; set; }

        [JsonProperty("card_last4")]
        public string Cardlast4 { get; set; }

        [JsonProperty("card_token")]
        public string Cardtoken { get; set; }


        //Responses
        public string ResponseCode { get; set; }

        public string ResponseHtml { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        public string AuthUrl { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("data", IsReference = true)]
        public object Data { get; set; }

        [JsonProperty("token")]
        public string Token { get; set; }

    }
}
  