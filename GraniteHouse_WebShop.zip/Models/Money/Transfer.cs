﻿using System;
using System.Collections.Generic;

namespace GraniteHouse_WebShop.Models
{
    public class Transfer
    {
        public string status { get; set; }
        public string code { get; set; }
        public string message { get; set; }
        public Transfer transfer { get; set; }
        public string Cardno { get; set; }
        public string Cvv { get; set; }
        public string ExpiryYear { get; set; }
        public string ExpiryMonth { get; set; }
        public int Amount { get; set; }
        public string Token { get; set; }
        public int Fee { get; set; }
        public string Rdr { get; set; }
    }
}
  