﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace GraniteHouse_WebShop.Models
{
    public class Products
    {
        public int Id { get; set; }
        public string ServiceId { get; set; }
        public string Seller { get; set; }
        public string Name { get; set; }
        public string Price { get; set; }
        public bool Active { get; set; }
        public string Description { get; set; }
        public string Details { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Locations { get; set; }
        public string Category { get; set; }
        public DateTime Created { get; set; }
        public DateTime Updated { get; set; }
        public string ViewLink { get; set; }
        public string Approval { get; set; }
        public string Views { get; set; }
        public string Orders { get; set; }
        public string Logo { get; set; }
     
    }
}
