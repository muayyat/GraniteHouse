﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
namespace GraniteHouse_WebShop.Models
{
    public class Bookings
    {
        public int Id { get; set; }
        public string Service { get; set; }
        public string Seller { get; set; }
        public string Adder { get; set; }
        public string BookingId { get; set; }
        public string BookingDetails { get; set; }
        public DateTime BDate { get; set; }
        public string Approval { get; set; }
        public string ANote { get; set; }
        public DateTime ADate { get; set; }
        public string Fulfilment { get; set; }
        public DateTime FDate { get; set; }
        public string FNote { get; set; }
        public string Payment { get; set; }
        public DateTime PDate { get; set; }
        public string Complaint { get; set; }
        public string Amount { get; set; }
        public string Feedback { get; set; }
       }
}
