﻿using System;
using System.Collections.Generic;
using System.Text;
using GraniteHouse_WebShop.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace GraniteHouse_WebShop.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Products> Products { get; set; }
        public DbSet<Bookings> Bookings { get; set; }
        public DbSet<Profiles> Profiles { get; set; }
        public DbSet<Subscriptions> Subscriptions { get; set; }
        public DbSet<Contact> Contact { get; set; }
        public DbSet<Images> Images { get; set; }
        public DbSet<Albums> Albums { get; set; }
        public DbSet<Payer> Payer { get; set; }
        
    }
}
