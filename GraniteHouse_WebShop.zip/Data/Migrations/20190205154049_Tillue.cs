﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GraniteHouse_WebShop.Data.Migrations
{
    public partial class Tillue : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Location",
                table: "Products",
                newName: "Views");

            migrationBuilder.AddColumn<string>(
                name: "Address",
                table: "Products",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Approval",
                table: "Products",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Locations",
                table: "Products",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Orders",
                table: "Products",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ViewLink",
                table: "Products",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Address",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "Approval",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "Locations",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "Orders",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "ViewLink",
                table: "Products");

            migrationBuilder.RenameColumn(
                name: "Views",
                table: "Products",
                newName: "Location");
        }
    }
}
