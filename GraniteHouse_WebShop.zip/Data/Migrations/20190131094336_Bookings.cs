﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace GraniteHouse_WebShop.Data.Migrations
{
    public partial class Bookings : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Bookings",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Seller = table.Column<string>(nullable: true),
                    Adder = table.Column<string>(nullable: true),
                    BookingId = table.Column<string>(nullable: true),
                    BookingDetails = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    Complaint = table.Column<string>(nullable: true),
                    Amount = table.Column<string>(nullable: true),
                    DateOrdered = table.Column<string>(nullable: true),
                    DateFulfilled = table.Column<string>(nullable: true),
                    FulfilNote = table.Column<string>(nullable: true),
                    ApprovalNote = table.Column<string>(nullable: true),
                    DatePayed = table.Column<string>(nullable: true),
                    Notes = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bookings", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Bookings");
        }
    }
}
