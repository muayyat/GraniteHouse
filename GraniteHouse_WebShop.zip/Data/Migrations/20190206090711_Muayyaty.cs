﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace GraniteHouse_WebShop.Data.Migrations
{
    public partial class Muayyaty : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Profiles",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Seller = table.Column<string>(nullable: true),
                    Fullname = table.Column<string>(nullable: true),
                    Country = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    Method = table.Column<string>(nullable: true),
                    BankName = table.Column<string>(nullable: true),
                    BankCountry = table.Column<string>(nullable: true),
                    BankActNo = table.Column<string>(nullable: true),
                    BankSwift = table.Column<string>(nullable: true),
                    BankActName = table.Column<string>(nullable: true),
                    Paypal = table.Column<string>(nullable: true),
                    Niche = table.Column<string>(nullable: true),
                    Bizmail = table.Column<string>(nullable: true),
                    BizName = table.Column<string>(nullable: true),
                    BizCountry = table.Column<string>(nullable: true),
                    BizAddress = table.Column<string>(nullable: true),
                    BizReg = table.Column<string>(nullable: true),
                    Policy = table.Column<string>(nullable: true),
                    Tips = table.Column<string>(nullable: true),
                    Orders = table.Column<string>(nullable: true),
                    Offers = table.Column<string>(nullable: true),
                    Updated = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Profiles", x => x.Id);
                });
        }


        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
