﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GraniteHouse_WebShop.Data.Migrations
{
    public partial class Summy : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Service",
                table: "Bookings",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Service",
                table: "Bookings");
        }
    }
}
