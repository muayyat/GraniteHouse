﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace GraniteHouse_WebShop.Data.Migrations
{
    public partial class Restructure : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ApprovalNote",
                table: "Bookings");

            migrationBuilder.RenameColumn(
                name: "Status",
                table: "Bookings",
                newName: "Payment");

            migrationBuilder.RenameColumn(
                name: "Notes",
                table: "Bookings",
                newName: "Fulfilment");

            migrationBuilder.RenameColumn(
                name: "FulfilNote",
                table: "Bookings",
                newName: "Feedback");

            migrationBuilder.RenameColumn(
                name: "DatePayed",
                table: "Bookings",
                newName: "FNote");

            migrationBuilder.RenameColumn(
                name: "DateOrdered",
                table: "Bookings",
                newName: "Approval");

            migrationBuilder.RenameColumn(
                name: "DateFulfilled",
                table: "Bookings",
                newName: "ANote");

            migrationBuilder.AddColumn<DateTime>(
                name: "ADate",
                table: "Bookings",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "BDate",
                table: "Bookings",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "FDate",
                table: "Bookings",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "PDate",
                table: "Bookings",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ADate",
                table: "Bookings");

            migrationBuilder.DropColumn(
                name: "BDate",
                table: "Bookings");

            migrationBuilder.DropColumn(
                name: "FDate",
                table: "Bookings");

            migrationBuilder.DropColumn(
                name: "PDate",
                table: "Bookings");

            migrationBuilder.RenameColumn(
                name: "Payment",
                table: "Bookings",
                newName: "Status");

            migrationBuilder.RenameColumn(
                name: "Fulfilment",
                table: "Bookings",
                newName: "Notes");

            migrationBuilder.RenameColumn(
                name: "Feedback",
                table: "Bookings",
                newName: "FulfilNote");

            migrationBuilder.RenameColumn(
                name: "FNote",
                table: "Bookings",
                newName: "DatePayed");

            migrationBuilder.RenameColumn(
                name: "Approval",
                table: "Bookings",
                newName: "DateOrdered");

            migrationBuilder.RenameColumn(
                name: "ANote",
                table: "Bookings",
                newName: "DateFulfilled");

            migrationBuilder.AddColumn<string>(
                name: "ApprovalNote",
                table: "Bookings",
                nullable: true);
        }
    }
}
